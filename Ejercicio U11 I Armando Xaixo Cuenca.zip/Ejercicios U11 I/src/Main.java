import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        String cont = null;
        do {
            String a = Leer.leerTexto("Introdueix una ruta : ");
            try {
                muestraInfoRuta(a);
            } catch (FileNotFoundException ex) {
                System.out.println(ex);
            }
            cont = Leer.leerTexto("Vols continuar?");
        } while (cont.equalsIgnoreCase("si"));
    }

    public static void muestraInfoRuta(String file) throws FileNotFoundException {
        File b = new File(file);
        if (!b.exists()) {
            throw new FileNotFoundException("La ruta no existeix");
        }
        if (b.isFile()) {
            System.out.println("La ruta introduida es un fitxer: ");
            System.out.println("- " + b.getName());
        } else if (b.isDirectory()) {
            System.out.println("La ruta introduida es un directori: ");
            System.out.println("d " + b.getName());
            System.out.println("\n Subdirectoris: ");
            File []llista = b.listFiles();
            for (File llist : llista) {
                if (llist.isFile()) {
                    System.out.println("- " + llist.getName());
                } else if (llist.isDirectory()) {
                    System.out.println("d " + llist.getName());
                }
            }
        }
    }
}