import java.io.File;

public class Ejercicio2 {
    public static void main(String[] args) {
        System.out.println("Programam per a cambiar el nom dels directoris i llevar la extensio dels archius de les carpetes.");
        File a = new File("C:\\Users\\borpelmon\\provafile\\Documentos");
        File b = new File(a.getParent(),"DOCS");
        a.renameTo(b);
        System.out.println("Nom del document cambiat");
        File c = new File("C:\\Usuaris\\armxaicue\\ejerciciprova\\Imagenes");
        File d = new File(c.getParent(),"IMGS");
        c.renameTo(d);
        System.out.println("Nom de Imagens cambiat");
        String []llistaString;
        for (File e : b.listFiles()) {
            llistaString = e.getName().split("\\.");
            File split = new File(e.getParent() + "/" + llistaString[0]);
            e.renameTo(split);
        }
        System.out.println("\nExtensions de la carpeta documents eliminades");
        for (File e : b.listFiles()) {
            System.out.println(e);
        }

        String []listaString;
        for (File f : d.listFiles()) {
            listaString = f.getName().split("\\.");
            File splits = new File(f.getParent() + "/" + listaString[0]);
            f.renameTo(splits);
        }
        System.out.println("\nExtensions de la carpeta imagenes eliminades");
        for (File llistes : d.listFiles()) {
            System.out.println(llistes);
        }

    }
}
