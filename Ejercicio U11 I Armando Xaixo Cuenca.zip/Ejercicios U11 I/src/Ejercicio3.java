import java.io.File;
import java.io.FileNotFoundException;

public class Ejercicio3 {
    public static void main(String[] args) throws FileNotFoundException {
        String a = Leer.leerTexto("Introdueix una ruta de archius que vols eliminar: ");
        borraTodo(a);
    }

    public static boolean borraTodo(String f) throws FileNotFoundException {
        Boolean b=false;
        File a = new File(f);
        if (!a.exists()) {
            throw new FileNotFoundException("La ruta no es troba");
        }
        if (a.isFile()) {
            a.delete();
            b=true;
        }
        if (a.isDirectory()) {
            for (File c : a.listFiles()) {
                c.delete();
            }
            a.delete();
            b=true;
        }
        return b;
    }
}
