public class Chalet extends Casa {
    private int mantener;
    private int mjardin;
    private String colorvalla;

    public Chalet(int ve, int pu, String co, int man, int mj) {
        super(ve, pu, co);
        this.mantener = man;
        this.mjardin = mj;


    }

    public void aumentaMantener() {
        this.mantener *= 1.02;


    }

    public void pintaChalet(String pintarvalla) {
        this.colorvalla = pintarvalla;

    }

    public int getMjardin() {
        return mjardin;
    }

    public void mostrarDatos() {
        System.out.println("El chalet tiene " + this.getNpuertas() + " puertas, " + this.getNventanas()  +" ventanas y  " + this.getMjardin() + " m2 de jardin ");
    }

    @Override
    public String toString() {
        return getClass().getName() + "-" + this.getColor();
    }
}
