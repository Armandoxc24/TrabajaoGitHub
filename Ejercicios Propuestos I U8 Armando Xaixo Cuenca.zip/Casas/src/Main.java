import javax.swing.text.AbstractDocument;

public class Main {
    public static void main(String[] args) {
        System.out.println("MENU");
        System.out.println("Puedes elegir entre la parte1 o la parte2: ");
        int eleccio = Leer.leerEntero("Disme un numero del 1 al 2:");
        switch (eleccio) {
            case 1:
                Casa a = new Casa(5,2, "azul");
                a.mostrarDatos();
                Piso b = new Piso(10,5,"blanco", 3, 6);
                b.mostrarDatos();
                Chalet c = new Chalet(4, 3,"marron", 5000, 20);
                c.mostrarDatos();
                c.pintaChalet("blanca");
                Adosado d = new Adosado(8,6, "rojo", 2, false);
                d.mostrarDatos();
                Casa e = new Casa(5,2, "azul");
                e.mostrarDatos();
                Piso f = new Piso(10,5,"blanco", 3, 6);
                f.mostrarDatos();
                Chalet g = new Chalet(8, 6,"naranja", 10000, 20);
                g.mostrarDatos();
                g.aumentaMantener();
                g.pintaChalet("blanca");
                Adosado h = new Adosado(10,15, "blanco", 5, true);
                h.mostrarDatos();
            case 2:
                int casas = Leer.leerEntero("Disme el numero de cases que vols:");
                Casa[] casa = new Casa[casas];
                for (int i = 0; i<casas;i++) {
                    String propiedad = Leer.leerTexto("Que tipo de propiedad quieres(Chalet,Adosado,Piso: ");
                    int puertas = Leer.leerEntero("Disme el numero de portes que vols: ");
                    int ventanas = Leer.leerEntero("Disme el numero de finestres que vols: ");
                    String color = Leer.leerTexto("Disme el color que vols per a la teua propietat: ");
                    switch (propiedad.toLowerCase()) {
                        case "chalet":
                            String colorvalla = Leer.leerTexto("Disme el color de la valla: ");
                            int jardin = Leer.leerEntero("Disme el m2 que te el jardi: ");
                            int mantener = Leer.leerEntero("Disme el dines que costa de mantindre: ");
                            casa[i] = new Chalet(ventanas,puertas,colorvalla,mantener,jardin);
                            break;
                        case "adosado":
                            int cochera = Leer.leerEntero("Disme el numero de cocheres que tens: ");
                            boolean pati = Boolean.parseBoolean(Leer.leerTexto("Tienes patio?(true/false)"));
                            casa[i] = new Adosado(ventanas,puertas,color,cochera,pati);
                            break;
                        case "piso":
                            int planta = Leer.leerEntero("Disme el numero de plantes que te: ");
                            int balcons = Leer.leerEntero("Disme el numero de balcons que tens: ");
                            casa[i] = new Piso(ventanas,puertas,color,planta,balcons);
                            break;
                        default:
                            System.out.println("Introdueix un tipo de casa correcte: ");

                    }
                }
                for (Casa ca :  casa) {
                    System.out.println(ca);

                }
                for (Casa l : casa) {
                    l.mostrarDatos();
                }

        }
    }
}