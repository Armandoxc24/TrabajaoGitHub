public class Casa {
    private int nventanas;
    private int npuertas;
    private String color;

    public Casa (int ve, int pu, String co) {
        this.nventanas = ve;
        this.npuertas = pu;
        this.color = co;


    }

    public int getNpuertas() {
        return npuertas;
    }
    public int getNventanas() {
        return nventanas;
    }

    public String getColor() {
        return color;
    }

    public void mostrarDatos() {
        System.out.println("La casa tiene " + this.getNpuertas() + " puertas, " + this.getNventanas() + " ventanas");
    }

    @Override
    public String toString() {
        return "superior" + getClass().getName() + "-" + color;
    }
}
