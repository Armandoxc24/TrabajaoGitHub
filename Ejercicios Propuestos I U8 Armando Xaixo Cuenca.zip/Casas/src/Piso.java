public class Piso extends Casa{
    private int nplanta;
    private int balcons;

    public Piso(int ve, int pu, String co, int npla, int balc) {
        super(ve, pu, co);
        this.nplanta = npla;
        this.balcons = balc;
    }

    public int getBalcons() {
        return balcons;
    }
    public void mostrarDatos() {
        System.out.println("El piso " + this.getNpuertas() + " puertas, " + this.getNventanas() + " ventanas y  " + this.getBalcons() + " balcons " );
    }

    @Override
    public String toString() {
        return getClass().getName() + "-" + this.getColor();
    }
}

