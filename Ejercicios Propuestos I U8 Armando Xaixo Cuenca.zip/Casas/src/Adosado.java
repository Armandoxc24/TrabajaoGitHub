public class Adosado extends Casa{
    private int npcocheres;
    private boolean pati;
    public Adosado(int ve, int pu, String co, int npco, boolean pa) {
        super(ve, pu, co);
        this.npcocheres = npco;
        this.pati = pa;
    }

    public int getNpcocheres() {
        return npcocheres;
    }
    public void mostrarDatos() {
        if(this.pati)
            System.out.println("El adosado tiene " + this.getNpuertas() + " puertas, " + getNventanas() + " ventanas, " + this.getNpcocheres() + " plaza de cochera pero no tiene patio ");
        else
            System.out.println("El adosado tiene " + this.getNpuertas() + " puertas, " + getNventanas() + " ventanas, " + this.getNpcocheres() + " plaza de cochera y patio ");
    }

    @Override
    public String toString() {
        return getClass().getName() + "-" + this.getColor();
    }
}
