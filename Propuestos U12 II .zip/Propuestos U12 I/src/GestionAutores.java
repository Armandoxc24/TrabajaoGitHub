public class GestionAutores {
    public static boolean menuautores() {
        System.out.println("MENU");
        System.out.println("1-Crear Tabla Autores");
        System.out.println("2-Insertar Datos Iniciales");
        System.out.println("3-Lista Autores");
        System.out.println("4-Nuevo Autor");
        System.out.println("5-Modificar Autor");
        System.out.println("6-Eliminar Autor");
        System.out.println("0-Salir");

        int opcion = Leer.leerEntero("Escribe un numero del 3 al 6: ");
        switch (opcion) {
           case 3:
                opcionMostrarAutores();
                break;
            case 4:
                opcionNuevoAutor();
                break;
            case 5:
                opcionModificarAutor();
                break;
            case 6:
                opcionEliminarAutor();
                break;
            case 0:
                return true;
            default:
                System.out.println("Opcion no valida");
        }
        return false;

    }
    public static void opcionMostrarAutores() {
        System.out.println("\nListado de Autores:");
        System.out.println("------------------");
        DBManager.mostrarAutores();
    }

    public static void opcionNuevoAutor() {

        System.out.println("\nIntroduce los datos del nuevo autor:");
        System.out.println("------------------------------------");
        String nombre = Leer.leerTexto("Nombre: ");

        Boolean res = DBManager.nuevoautor(nombre);

        if (res) {
            System.out.println("Autor registrado correctamente");
        } else {
            System.out.println("Error :(");
        }

    }

    public static void opcionModificarAutor() {

        int id = Leer.leerEntero("Indica el id del autor a modificar: ");


        if (!DBManager.existsautor(id)) {
            System.out.println("El autor " + id + " no existe.");
            return;
        }
        DBManager.printautor(id);
        String nuevoNombre = Leer.leerTexto("Nuevo nombre: ");
        boolean res = DBManager.modificarAutor(id,nuevoNombre);

        if (res) {
            System.out.println("Autor modificado correctamente");
        } else {
            System.out.println("Error :(");
        }

    }

    public static void opcionEliminarAutor() {

        int id = Leer.leerEntero("Indica el id del autor a eliminar: ");


        if (!DBManager.existsAutor(id)) {
            System.out.println("El autor " + id + " no existe.");
            return;
        }


        boolean res = DBManager.eliminarAutor(id);

        if (res) {
            System.out.println("Autor eliminado correctamente");
        } else {
            System.out.println("Error :(");
        }
    }
}