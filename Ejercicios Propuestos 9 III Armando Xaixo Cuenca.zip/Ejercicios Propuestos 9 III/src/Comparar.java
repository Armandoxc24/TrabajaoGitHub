public interface Comparar {
    boolean esMayor(Departamento dep);
    boolean esMenor(Departamento dep);
    boolean esIgual(Departamento dep);
}
