import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        ArrayList<Departamento> departament = new ArrayList<>();


        departament.add(new Departamento("Informatica", 100));
        departament.add(new Departamento("Programacio", 50));

        System.out.println("Departaments Desordenats:");
        for (Departamento depar : departament) {
            System.out.println(depar);
        }
        if (departament.get(0).esMayor(departament.get(1)))
            System.out.println("El departament: " + departament.get(0) + " Es major que el departament: " + departament.get(1));
        else if (departament.get(0).esMenor(departament.get(1)))
            System.out.println("El departament: " + departament.get(1) + " Es major que el departament: " + departament.get(0));
        else if (departament.get(0).esIgual(departament.get(1)))
            System.out.println(departament.get(0).compareTo(departament.get(1)));

        Collections.sort(departament);

        System.out.println("Departaments Ordenats(nom i cantitat de empleats):");
        for (Departamento dep : departament) {
            System.out.println(dep);
        }

        Factura factura0 = new Factura(1, new Date(2024, 8, 24), 1000.0f);
        Factura factura1 = new Factura(2, new Date(2024, 8, 2), 600.0f);
        System.out.println();
        Comparator<Factura> comparadorImporteFecha = new Numerofactura.ImporteFecha();
        Factura mayorPorImporteFecha = Collections.max(List.of(factura0, factura1), comparadorImporteFecha);
        System.out.println("Factura amb major import:");
        System.out.println(mayorPorImporteFecha);

        ArrayList<Factura> facturas = new ArrayList<>();
        facturas.add(new Factura(3, new Date(2024, 8, 13), 800.0f));
        facturas.add(new Factura(4, new Date(2024, 8, 26), 200.0f));
        facturas.add(new Factura(5, new Date(2024, 8, 10), 500.0f));
        System.out.println();
        System.out.println("ArrayList de factures sense ordenar:");
        for (Factura factura : facturas) {
            System.out.println(factura);
        }
        System.out.println();
        Collections.sort(facturas, new Numerofactura());
        System.out.println("ArrayList de facturas ordenadas per número de factura:");
        for (Factura factura : facturas) {
            System.out.println(factura);
        }
        System.out.println();
        Collections.sort(facturas, new Numerofactura.FechaImp());
        System.out.println("ArrayList de factures ordenades per fecha i despues per import:");
        for (Factura factura : facturas) {
            System.out.println(factura);
        }
        System.out.println();
        Collections.sort(facturas, new Numerofactura.ImporteFecha());
        System.out.println("ArrayList de factures ordenades per import i despues per fecha:");
        for (Factura factura : facturas) {
            System.out.println(factura);
        }
    }
}