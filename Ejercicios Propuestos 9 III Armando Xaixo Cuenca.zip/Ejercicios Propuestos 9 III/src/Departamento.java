public class Departamento implements Comparar,Comparable<Departamento> {

    private String nombre;
    private int cantidaddeempleados;
    public Departamento(String nombre, int cantidaddeempleados){
       this.nombre=nombre;
       this.cantidaddeempleados=cantidaddeempleados;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCantidaddeempleados() {
        return cantidaddeempleados;
    }

    public boolean esMayor(Departamento otroDepartamento) {
        return this.cantidaddeempleados > otroDepartamento.getCantidaddeempleados();
    }

    public boolean esMenor(Departamento otroDepartamento) {
        return this.cantidaddeempleados < otroDepartamento.getCantidaddeempleados();
    }

    public boolean esIgual(Departamento otroDepartamento) {
        return this.cantidaddeempleados == otroDepartamento.getCantidaddeempleados();
    }
    public String toString() {
        return "Departament - " +
                "nom: " + nombre +
                ", cantitat de Empleats: " + cantidaddeempleados;
    }

    @Override
    public int compareTo(Departamento o) {
        int c= this.cantidaddeempleados - o.cantidaddeempleados;
        if (c == 0) {
            return this.nombre.compareTo(o.nombre);
        }
        return c;
    }
}

