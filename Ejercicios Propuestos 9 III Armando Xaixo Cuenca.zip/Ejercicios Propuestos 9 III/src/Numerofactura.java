import java.util.Comparator;

public class Numerofactura implements Comparator<Factura>{

    @Override
    public int compare(Factura o1, Factura o2) {
        return Integer.compare(o1.getNumero(), o2.getNumero());
    }
public static class FechaImp implements Comparator<Factura>{
    @Override
    public int compare(Factura o1, Factura o2) {
        int compararFecha = o1.getFecha().compareTo(o2.getFecha());
        if (compararFecha == 0) {
            return Float.compare(o1.getImporte(), o2.getImporte());
        }
        return compararFecha;
    }
}
public static class ImporteFecha implements Comparator<Factura> {
    @Override
    public int compare(Factura o1, Factura o2) {
        int comparacionImporte = Float.compare(o1.getImporte(), o2.getImporte());
        if (comparacionImporte == 0) {
            return o1.getFecha().compareTo(o2.getFecha());
        }
        return comparacionImporte;
    }
}
}

