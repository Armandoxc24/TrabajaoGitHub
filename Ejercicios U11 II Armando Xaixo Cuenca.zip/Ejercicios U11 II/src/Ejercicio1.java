import java.io.*;

public class Ejercicio1 {
    public static void main(String[] args) throws IOException {
        String a =Leer.leerTexto("Introduce la ruta de un archivo de texto: ");
        File f = new File(a);
        if(!f.exists()) {
            throw new FileNotFoundException("La ruta no existe");
        }
        else if(f.isDirectory()){
            System.out.println("Introduce una ruta que no sea directorio: ");
        }
        else if(f.isFile()) {
        FileReader fr = new FileReader(f);
        BufferedReader bfr = new BufferedReader(fr);
        String b ="";
        int c=0;
        int d=1;
        while (bfr.ready()){
            b=bfr.readLine();
            c+=b.length();
            if (!b.isEmpty()){
                System.out.println("\nParragraf " + d + " : ");
                System.out.println( b );
                System.out.println("Numero de caracters " + c);
                d+=1;
            }
            c=0;
        }
        bfr.close();
        fr.close();
        }
    }
}