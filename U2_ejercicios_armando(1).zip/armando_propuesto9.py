#EXERCICI9

peso=int(input("Disme el teu pes "))
altura=int(input("Disme la teua altura "))

imc=((peso)/(altura**2))

print("La formaula del IMC es", imc)