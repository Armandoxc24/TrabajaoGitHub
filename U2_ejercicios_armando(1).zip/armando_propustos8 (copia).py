#Exercici8


print ( "Libro".ljust(30) + "Autor")
print ( "El Quijote".ljust(30) + "Cervantes")
print ( "Harry Potter y las Reliquias".ljust(30) + "HK Rowling")
print ( "Carlos en tu cocina".ljust(30) + "Karlos Arguiñano")
