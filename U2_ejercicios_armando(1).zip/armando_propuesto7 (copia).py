#Exercici7

a=int(input("Disme la base del triangle "))

b=int(input("Disme la altura del triangle "))

area= ((b) * (a))

print("La area del triangulo es " + str (area))



          